
# Average Calculator Microservice

## Backend (Node.js)
1. Run `npm install express axios`
2. Start server with `node server.js`

## Frontend
Open `index.html` in your browser.
Make sure the backend is running at http://localhost:9876
