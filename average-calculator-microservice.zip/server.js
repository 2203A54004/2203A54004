
const express = require('express');
const axios = require('axios');
const app = express();
const PORT = 9876;
const windowSize = 10;

let numberStore = {
  p: [], f: [], e: [], r: []
};

const apiEndpoints = {
  p: 'http://20.244.56.144/evaluation-service/primes',
  f: 'http://20.244.56.144/evaluation-service/fibo',
  e: 'http://20.244.56.144/evaluation-service/even',
  r: 'http://20.244.56.144/evaluation-service/rand',
};

function calculateAverage(arr) {
  const sum = arr.reduce((a, b) => a + b, 0);
  return parseFloat((sum / arr.length).toFixed(2));
}

app.get('/numbers/:id', async (req, res) => {
  const id = req.params.id;
  if (!apiEndpoints[id]) return res.status(400).send('Invalid ID');

  try {
    const response = await axios.get(apiEndpoints[id], { timeout: 500 });
    const newNumbers = response.data.numbers.filter(n => !numberStore[id].includes(n));

    numberStore[id] = [...numberStore[id], ...newNumbers].slice(-windowSize);
    const avg = calculateAverage(numberStore[id]);

    res.json({
      windowPrevState: numberStore[id].slice(0, -newNumbers.length),
      windowCurrState: numberStore[id],
      numbers: newNumbers,
      avg: avg
    });
  } catch (error) {
    res.status(500).send('Error fetching numbers');
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
